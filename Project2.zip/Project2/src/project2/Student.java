
package project2;

import java.io.*;
import java.io.Serializable;
import java.util.*;

public class Student implements Serializable{
    
   private int studentID;
   private String studentName;
   private String Password;
   private int Age;
   private String CNIC;
   private int Semester;
   private String Program;
   private String Username;
    
    private ArrayList <Course> courses;
    private ArrayList <Student> students;
    
    //Creating a File 
    private static final File StudentFile = new File ("Students.txt");
    
    public Student() {
        //Empty constructor
        courses= new ArrayList <Course> ();
        students= new ArrayList <Student> ();
    }

    public Student(int studentID, String studentName, String Password, int Age, String CNIC, int Semester, String program , String  username) {
        this.studentID = studentID;
        this.studentName = studentName;
        this.Password = Password;
        this.Age = Age;
        this.CNIC = CNIC;
        this.Semester = Semester;
        this.Program = program;
        this.Username = username;
    }
    
    public Student(int studentID, String studentName, String Password, int Age, String CNIC, int Semester , ArrayList <Course> courses) {
        this.studentID = studentID;
        this.studentName = studentName;
        this.Password = Password;
        this.Age = Age;
        this.CNIC = CNIC;
        this.Semester = Semester;
        this.courses = courses; 
    }

    
    
    public void deleteStudentFile() {
        StudentFile.delete();
    }
    
    public void AddStudent (ArrayList <Student> students) throws FileNotFoundException{
        
        this.students = students;
        
        // Creating a File if not exitsts
        if (!StudentFile.exists()) {
            
            try {
                StudentFile.createNewFile();
            } 
            
            catch (IOException ex) {
               // Logger.getLogger(University.class.getName()).log(Level.SEVERE, null, ex);
               ex.printStackTrace();
            }
        }
        
        try {
            //Adding courses in file
            
            ObjectOutputStream out= new ObjectOutputStream (new FileOutputStream("Students.txt"));
            
            out.writeObject(students);
            out.close();
        } 
        
        catch (IOException ex) {
           // Logger.getLogger(University.class.getName()).log(Level.SEVERE, null, ex);
           ex.printStackTrace();
        }
        
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }

    public String getCNIC() {
        return CNIC;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }

    public int getSemester() {
        return Semester;
    }

    public void setSemester(int Semester) {
        this.Semester = Semester;
    }

    public String getProgram() {
        return Program;
    }

    public void setProgram(String Program) {
        this.Program = Program;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public ArrayList<Course> getCourses() {
        return courses;
    }

    public void setCourses(ArrayList<Course> courses) {
        this.courses = courses;
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    public void setStudents(ArrayList<Student> students) {
        this.students = students;
    }
    
    
    
    @Override
    public String toString() {
        return "Student{" + "studentID=" + studentID + ", studentName=" + studentName + ", Password=" + Password + ", Age=" + Age + ", CNIC=" + CNIC + ", Semester=" + Semester + '}';
    }
    
}
