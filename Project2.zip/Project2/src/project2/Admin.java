
package project2;


public class Admin {
    private String Username;
    private String Password;
    
    
    public Admin() {
        this.Username= "Admin";
        this.Password= "admin";
        
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    
       
    public boolean loginValidaiton(String User, String Pass) {
        
     if ((Username.equals(User))&&(Password.equals(Pass))) {
         
         return true;
     }
        return false;
             
    }
    
}
