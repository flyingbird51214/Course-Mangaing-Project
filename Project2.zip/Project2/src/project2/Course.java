
package project2;

import java.io.*;
import java.io.Serializable;
import java.util.*;

public class Course  implements Serializable{
    
    private int courseID;
    private String Name;
    private String Type;
    private int Semester;
    private int creditHours;
    private String Program;
    private int Section;
    
    private ArrayList <Course> courses;
    private ArrayList <Student> students; 
    
    //Creating a Course File Object
    private static final File CourseFile = new File ("Courses.txt");
    
    public Course(){
        //Empty Constructor
        courses  = new  ArrayList<Course>();
        students = new ArrayList<Student>(); 
    }
    
    public void deleteFile() {
        
        CourseFile.delete();
    }

    public Course(int courseID, String Name, String Type, int Semester, int creditHours, String Program, int Section) {
        this.courseID = courseID;
        this.Name = Name;
        this.Type = Type;
        this.Semester = Semester;
        this.creditHours = creditHours;
        this.Program = Program;
        this.Section = Section; 
    }
    
    public Course(int courseID, String Name, String Type, int Semester, int creditHours, String Program, int Section, ArrayList <Student> students) {
        this.courseID = courseID;
        this.Name = Name;
        this.Type = Type;
        this.Semester = Semester;
        this.creditHours = creditHours;
        this.Program = Program;
        this.Section = Section; 
       // this.students= students;
    }
           
    public void AddCourse (ArrayList <Course> courses) throws FileNotFoundException {
        
        this.courses = courses;
        
        // Creating a File if not exitstsAd
        if (!CourseFile.exists()) {
            
            try {
                CourseFile.createNewFile();
            } 
            
            catch (IOException ex) {
                //Logger.getLogger(University.class.getName()).log(Level.SEVERE, null, ex);
                ex.printStackTrace();
            }
        }
        
        try {
            //Adding courses in file
            
            ObjectOutputStream out= new ObjectOutputStream (new FileOutputStream("Courses.txt"));
            
            out.writeObject(courses);
            out.close();
        } 
        
        catch (IOException ex) {
           // Logger.getLogger(University.class.getName()).log(Level.SEVERE, null, ex);
           ex.printStackTrace();
        }
        
    }
    public void updateCourse(int id,String Name, String Type, int Semester, int creditHours, String Program, int Section)
    {
        for(Course c : courses)
        {
            if(c.getCourseID() == id)
            {
                c.setCourseID(courseID);
                c.setName(Name);
                c.setType(Type);
                c.setSemester(Semester);
                c.setCreditHours(creditHours);
                c.setProgram(Program);
                c.setSection(Section);
               // c.setCourseTitle(title);
               // c.setCourseDescription(description);
                updateInDB();
                break;
            }
        }
    }
    private void writeToFile(PrintWriter out , Course c)
    {
        
        out.println(c.getCourseID());
        out.println(c.getName());
        out.println(c.getType());
        out.println(c.getSemester());
        out.println(c.getCreditHours());
        out.println(c.getProgram());
        out.println(c.getSection());
        out.flush();
    }
    
    private void updateInDB(){
        try{
            PrintWriter out = new PrintWriter(new FileWriter(CourseFile));
            for(Course c : courses){
                writeToFile(out , c);
            }
            out.close();
        } catch(Exception e){
            e.printStackTrace();
        }
    }
    public void removeStudent(Student s) {
        
     int index= -1;
     boolean check =false ;
     
     for (Student stud : students) {
         
         if (stud.getStudentID() == s.getStudentID() ) {
             index = students.indexOf(stud);
             check = students.remove(stud);
         }
     }
     
    students.remove(index);
     
        System.out.println(check);
    }
    
    public void clearSudents() {
        
        students.clear();
    }
    
    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public int getSemester() {
        return Semester;
    }

    public void setSemester(int Semester) {
        this.Semester = Semester;
    }

    public int getCreditHours() {
        return creditHours;
    }

    public void setCreditHours(int creditHours) {
        this.creditHours = creditHours;
    }

    public String getProgram() {
        return Program;
    }

    public void setProgram(String Program) {
        this.Program = Program;
    }
    
    public int getSection() {
        return Section;
    }
    
    public void setSection(int Section) {
        this.Section= Section;
    }

    public ArrayList<Course> getCourses() {
        return courses;
    }

    public void setCourses(ArrayList<Course> courses) {
        this.courses = courses;
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    public void setStudents(ArrayList<Student> students) {
        this.students.clear();
        this.students = students;
    }
    
    public void addStudent(Student student) { 
        students.add(student);
    }

    @Override
    public String toString() {
        return   Program  + Section+ courseID +   Name  + Type  + Semester + creditHours ;
    }   
    
}
