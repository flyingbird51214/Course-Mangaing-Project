/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project2;

import java.io.*;
import java.util.*;

/**
 *
 * @author 123
 */
public class University {
    private ArrayList <Course> courses;
    private ArrayList <Student> students;
    private ArrayList <Teacher> teachers;
    private static University university;
    
    private static final File CourseFile = new File ("Courses.txt");
    private static final File StudentFile = new File ("Students.txt");
    private static final File TeacherFile = new File ("Teachers.txt");
    
    University(){
        courses = new  ArrayList<Course>();
        students = new ArrayList<Student>();
        teachers = new ArrayList<Teacher>();
        LoadCourseData();
        LoadTeachersData();
        LoadStudentsData();
    }
    
    public static University getInstance(){
        if(university==null)
            university = new University();
        return university;
    }
    
    public void LoadCourseData(){
        //populate the memory data base
        try{
            Scanner in = new Scanner (new FileReader(CourseFile));
            while(in.hasNext()){
                int id = in.nextInt();
                String name = in.nextLine();
                String type = in.nextLine();
                in.nextLine();
                int semester = in.nextInt();
                int credits = in.nextInt();
                String program = in.nextLine();
                in.nextLine();
                int section = in.nextInt();
                Course c = new Course(id,name,type,semester,credits,program,section);
                courses.add(c);
            }
        }catch(Exception e){
            e.printStackTrace();
            
        }
    }
    
    public void addCourse(int id , String name , String type , int semester , int credits , String program , int section){
        Course c = new Course(id , name , type , semester , credits , program , section);
        courses.add(c);
        saveCourseToDB(c);
    }
    
    public ArrayList<Course> getCourses() {
        return courses;
    }
    
    public Object[] getAllCourses(){
        return courses.toArray();//gives copy of array
    }
        private void saveCourseToDB(Course c){
        try{
            PrintWriter out = new PrintWriter(new FileWriter(CourseFile,true));
            writeToFile(out,c);
            out.close();
            
            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
        private void writeToFile(PrintWriter out , Course c){
            out.println(c.getCourseID());
            out.println(c.getName());
            out.println(c.getType());
            out.println(c.getCreditHours());
            out.println(c.getSemester());
            out.println(c.getProgram());
            out.println(c.getSection());
            
            out.flush();
        }
        
        public void updateCourses(int id , String n , String t , int sem , int ch ,String prog , int sec){
                                                                                       //searching for that specific fooditem,needed to be update//updated in memory database
        for(Course c: courses){
            if(c.getCourseID()== id){
                c.setCourseID(id);
                c.setName(n);
                c.setType(t);
                c.setCreditHours(ch);
                c.setSemester(sem);
                c.setProgram(prog);
                c.setSection(sec);
                updateCourseInDB();
                break;
            }
        }   
    }
        private void updateCourseInDB(){
      try{
          PrintWriter out =new PrintWriter(new FileWriter (CourseFile));
          for(Course c : courses){
              writeToFile(out,c);                                                          //ab yeh memory wala saara data update k saath wapis memory sy file data base mein aa jaye ga
          }
          out.close();
      }catch(IOException e){
          e.printStackTrace();
      }  
    }
        
        public void deleteCourses(int id){
        for(Course c : courses){
            if(c.getCourseID()==id);
            courses.remove(c);
            updateCourseInDB();
            break;
        }
    }
    public Course searchCourseById(int id){
        for(Course c : courses){
            if(c.getCourseID()== id){
                return c;
            }
        }
        return null;
    }
    
    
    public void LoadTeachersData(){
        //populate the memory data base
        try{
            Scanner in = new Scanner (new FileReader(TeacherFile));
            while(in.hasNext()){
                int id = in.nextInt();
                String name = in.nextLine();
                String cnic = in.nextLine();
                String username = in.nextLine();
                String password = in.nextLine();
                Teacher t = new Teacher(id , name , cnic , username , password);
                teachers.add(t);
            }
        }catch(Exception e){
            e.printStackTrace();
            
        }
    }
    public void addTeachers(int id , String name , String cnic , String username , String pass){
        Teacher t = new Teacher(id , name ,cnic , username , pass );
        teachers.add(t);
        saveTeacherToDB(t);
    }
    
    public ArrayList<Teacher> getTeachers() {
        return teachers;
    }
    
    public Object[] getAllTeachers(){
        return teachers.toArray();//gives copy of array
    }
    
        private void saveTeacherToDB(Teacher t){
        try{
            PrintWriter out = new PrintWriter(new FileWriter(TeacherFile,true));
            writeToFile(out,t);
            out.close();
            
            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
        private void writeToFile(PrintWriter out , Teacher t){
            out.println(t.getTeacherID());
            out.println(t.getName());
            out.println(t.getUsername());
            out.println(t.getPassword());
            out.println(t.getCNIC());
            
            out.flush();
        }
        
        public void updateTeachers(int id , String name , String cnic , String username , String pass){
                                                                                       //searching for that specific fooditem,needed to be update//updated in memory database
        for(Teacher t: teachers){
            if(t.getTeacherID() == id){
               t.setTeacherID(id);
               t.setName(name);
               t.setCNIC(cnic);
                updateTeacherInDB();
                break;
            }
        }   
    }
        private void updateTeacherInDB(){
      try{
          PrintWriter out =new PrintWriter(new FileWriter (TeacherFile));
          for(Teacher t : teachers){
            //ab yeh memory wala saara data update k saath wapis memory sy file data base mein aa jaye ga
          }
          out.close();
      }catch(IOException e){
          e.printStackTrace();
      }  
    }
        
        public void deleteTeachers(int id){
        for(Teacher t : teachers){
            if(t.getTeacherID()==id);
            courses.remove(t);
            updateTeacherInDB();
            break;
        }
    }
        public Teacher searchTaecherById(int id){
        for(Teacher t  : teachers){
            if(t.getTeacherID()== id){
                return t;
            }
        }
        return null;
    }
        
        public void LoadStudentsData(){
        //populate the memory data base
        try{
            Scanner in = new Scanner (new FileReader(StudentFile));
            while(in.hasNext()){
                int id = in.nextInt();
                String n = in.nextLine();
                String p = in.nextLine();
                in.nextLine();
                int a = in.nextInt();
                String cnic = in.nextLine();
                in.nextLine();
                int sem = in.nextInt();
                String prog = in.nextLine();
                String username = in.nextLine();
                Student s = new Student(id ,n ,p , a , cnic ,sem , prog , username);
                students.add(s);
            }
        }catch(Exception e){
            e.printStackTrace();
            
        }
    }
    
    public void addStudent(int id, String name, String pass, int age, String cnic, int semester, String program , String  username){
        Student s = new Student(id , name , pass ,age , cnic , semester , program , username);
        students.add(s);
        saveStudentToDB(s);
    }
    
    public ArrayList<Student> getStudents() {
        return students;
    }
    
    public Object[] getAllStudents(){
        return students.toArray();//gives copy of array
    }
    
    
        private void saveStudentToDB(Student s){
        try{
            PrintWriter out = new PrintWriter(new FileWriter(StudentFile,true));
            writeToFile(out,s);
            out.close();
            
            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
        private void writeToFile(PrintWriter out , Student s){
            out.println(s.getStudentID());
            out.println(s.getStudentName());
            out.println(s.getPassword());
            out.println(s.getCNIC());
            out.println(s.getSemester());
            out.println(s.getProgram());
            out.println(s.getUsername());
            out.println(s.getAge());
            
            out.flush();
        }
        
        public void updateStudents(int id , String name , String pass ,int age , String cnic ,  int semester ,String program , String username){
                                                                                       //searching for that specific fooditem,needed to be update//updated in memory database
        for(Student s : students){
            if(s.getStudentID() == id){
                s.setStudentID(id);
                s.setStudentName(name);
                s.setPassword(pass);
                s.setCNIC(cnic);
                s.setSemester(semester);
                s.setProgram(program);
                s.setUsername(username);
                s.setAge(age);
                updateStudentInDB();
                break;
            }
        }   
    }
        private void updateStudentInDB(){
      try{
          PrintWriter out =new PrintWriter(new FileWriter (StudentFile));
          for(Student s : students){
              writeToFile(out,s);                                                          //ab yeh memory wala saara data update k saath wapis memory sy file data base mein aa jaye ga
          }
          out.close();
      }catch(IOException e){
          e.printStackTrace();
      }  
    }
        public Student searchStudentById(int id){
        for(Student s : students){
            if(s.getStudentID()== id){
                return s;
            }
        }
        return null;
    }
        
        public void deleteStudent(int id){
        for(Student s : students){
            if(s.getStudentID()==id);
            courses.remove(s);
            updateTeacherInDB();
            break;
        }
    }
}
