package project2;

import java.io.*;
import java.io.Serializable;
import java.util.*;

public class Teacher implements Serializable {
    
    private int teacherID;
    private String Name;
    private String CNIC;
    private String Username;
    private String Password;
   
    
    private ArrayList <Course> AssingedCourses = new ArrayList <Course> ();
    private ArrayList <Teacher> teachers = new ArrayList <Teacher> ();

    //Creating a File
    private static final File TeacherFile = new File ("Teachers.txt");
    
    public Teacher(){
         // Empty constructor
    }
    
    public Teacher(int teacherID, String Name, String CNIC, String username , String Password) {
        this.teacherID = teacherID;
        this.Name = Name;
        this.CNIC = CNIC;
        this.Username = username;
        this.Password = Password;
    }
    
    public Teacher(int teacherID, String Name, String CNIC, String Password , ArrayList <Course> AssignedCourses ) {
        this.teacherID = teacherID;
        this.Name = Name;
        this.CNIC = CNIC;
        this.Password = Password;
        this.AssingedCourses = AssignedCourses;
    }

    

    public void deleteTeacherFile() {
        TeacherFile.delete();
    }
    
    public void AddTeacher (ArrayList <Teacher> teachers) throws FileNotFoundException{
        
        this.teachers = teachers ;
        
        // Creating a File if not exitsts
        if (!TeacherFile.exists()) {
            
            try {
                TeacherFile.createNewFile();
            } 
            
            catch (IOException ex) {
                //Logger.getLogger(University.class.getName()).log(Level.SEVERE, null, ex);
                ex.printStackTrace();
            }
        }
        
        try {
            //Adding courses in file
            
            ObjectOutputStream out= new ObjectOutputStream (new FileOutputStream("Teachers.txt"));
            
            out.writeObject(teachers);
            out.close();
        } 
        
        catch (IOException ex) {
           // Logger.getLogger(University.class.getName()).log(Level.SEVERE, null, ex);
           ex.printStackTrace();
        }
        
    }  
    
    public void removeCourse(Course c) {
        
        int index =  -1;
        
        for (Course cour: AssingedCourses) {
            
            if (cour.getCourseID() == c.getCourseID()) {
                System.out.println(cour.getName());
                index = AssingedCourses.indexOf(cour);
            }
        } 
        
        try {
        AssingedCourses.remove(index);
        }
        
        catch (IndexOutOfBoundsException e) {
            System.out.println("Index out of bound exception occurs.");
        }
    }
    
    public int getTeacherID() {
        return teacherID;
    }

    public void setTeacherID(int teacherID) {
        this.teacherID = teacherID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getCNIC() {
        return CNIC;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public ArrayList<Course> getAssingedCourses() {
        return AssingedCourses;
    }
    
    public void addAssignedCourses(Course course) {

        AssingedCourses.add(course);
    }

    public void setAssingedCourses(ArrayList<Course> AssingedCourses) {
        this.AssingedCourses = AssingedCourses;
    }

    @Override
    public String toString() {
        return "Teacher{" + "teacherID=" + teacherID + ", Name=" + Name + ", CNIC=" + CNIC + ", Password=" + Password + '}';
    }

    
    
}
